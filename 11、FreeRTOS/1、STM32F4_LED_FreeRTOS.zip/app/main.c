#include <stdint.h>
#include <stdio.h>
#include "FreeRTOS.h"
#include "task.h"
#include "board.h"
#include "led.h"

typedef struct
{
    led_desc_t *led;
    uint32_t period;
} led_blink_param_t;


static void led_blink_task(void *param)
{
    led_blink_param_t *blink = param;
    led_desc_t *led = blink->led;
    uint32_t period = blink->period;
    
    for (uint32_t t = 0; t < 20; t++)
    {
        led_on(*led);
        vTaskDelay(pdMS_TO_TICKS(period));
        led_off(*led);
        vTaskDelay(pdMS_TO_TICKS(period));
    }
    
    vTaskDelete(NULL);
}

int main(void)
{
    board_lowlevel_init();
    board_init();
    
    led_init(led1);
    led_init(led2);
    led_init(led3);
    
    static led_blink_param_t led_blink1 = {&led1, 500};
    static led_blink_param_t led_blink2 = {&led2, 300};
    static led_blink_param_t led_blink3 = {&led3, 100};
    xTaskCreate(led_blink_task, "blink1", 256, &led_blink1, 5, NULL);
    xTaskCreate(led_blink_task, "blink2", 256, &led_blink2, 5, NULL);
    xTaskCreate(led_blink_task, "blink3", 256, &led_blink3, 5, NULL);
    
    vTaskStartScheduler();
    
    return 0;
}

void vAssertCalled(const char *file, int line)
{
    printf("Assert Called: %s(%d)\n", file, line);
}

void vApplicationStackOverflowHook( TaskHandle_t xTask, char *pcTaskName)
{
    printf("Stack Overflowed: %s\n", pcTaskName);
    configASSERT(0);
}

void vApplicationMallocFailedHook( void )
{
    printf("Malloc Failed\n");
    configASSERT(0);
}
