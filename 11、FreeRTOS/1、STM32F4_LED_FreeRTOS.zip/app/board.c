#include <stdio.h>
#include "stm32f4xx.h"
#include "console.h"
#include "led_desc.h"
#include "led.h"

void board_lowlevel_init(void)
{
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
    
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);
}

void board_init(void)
{
    console_init();
    printf("[SYS] Build Date: %s %s\n", __DATE__, __TIME__);    
}

int fputc(int ch, FILE *f)
{
    USART_SendData(USART1, (uint8_t)ch);
    while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);
    return ch;
}

static struct led_desc _led1 = { GPIOE, GPIO_Pin_9, Bit_RESET, Bit_SET};
static struct led_desc _led2 = { GPIOB, GPIO_Pin_0, Bit_RESET, Bit_SET};
static struct led_desc _led3 = { GPIOB, GPIO_Pin_1, Bit_RESET, Bit_SET};
led_desc_t led1 = &_led1;
led_desc_t led2 = &_led2;
led_desc_t led3 = &_led3;
